## COMS W1004
## Spring 2021
## Programming Project 5 
## Due April 12 at 11:59PM 
_________________________________________

***Remember you cannot use late hour on this one! It must be submitted on time!***


### PROGRAMMING (70 points)

**Scrabble Help:**  The file `dictionary.txt` contains all of the words in the Official Scrabble Player's Dictionary, Second Edition. There are more recent editions, but I'm afraid they are copyright protected and I do not have permission to use them here. *Note: this list contains some offensive language.* Write a class, WordLists,  in Java that generates useful word lists for scrabble players using this list. 
 
Your class should contain the following methods:

* WordLists(String fileName):  a constructor that takes the name of the dictionary file as the only parameter.
* lengthN(int n):  returns an ArrayList of all length *n* words (Strings) in the dictionary file.
* endsWith(char lastLetter, int n):  returns an ArrayList of words of length *n* ending with the letter *lastLetter*
* containsLetter(char included, int index, int n):  returns an ArrayList of words of length *n* containing the letter *included* at position *index*. So for example the word "cannon" would be on the list returned by containsLetter('o',4,6) because it contains the letter 'o', at index 4, and is length 6. (Note: The index begins at 0!)
* multiLetter(int m, char included):  returns an ArrayList of words with exactly *m* occurrences of the letter *included*.
 

Use the included template for your WordLists.java file. Write your own test class WordTest.java for your WordLists class that tries these methods out and writes the word lists (the ArrayLists of strings) to ***text*** files. Your test class should make a new text file for each of the four methods above. Your program should handle any exceptions that occur by terminating ***gracefully***. 

 
 
 
 
**What to hand in:**

A Template for the WordLists.java file is in the Programming Projet 5 workspace on Codio. You must write your own test class called WordTest.java (separate file with main method) that tests each of your methods and writes the results to a text file. In addition to the source files  include a text file named readMe.txt with an explanation of how your program works. That is, write in plain English, instructions for using your software, explanations for how and why you chose to design your code the way you did. The readMe.txt file is also an opportunity for you to get partial credit when certain requirements of the assignment are not met.   
 

### Submitting your work:
For this assignment you should have a total of three files: a readMe.txt file and two .java files templates for which are already loaded in your workspace on Codio. After you have filled out the templates you must export the files from Codio and load them onto Gradescope. In the navigation bar for Courseworks you will find a link to the course Gradescope page. Put your .java files and your readMe.txt file into a folder with the name [your UNI here]_project5 and compress this folder after which you should have a file that looks like ac1076_project5.zip except with your UNI instead of mine. Submit this file on Gradescope under Programming Project 5.


### A word about Grading: 
The programming portion of this assignment is worth 70 points. we will use the following guideline for awarding points:

* 30 points if it compiles  
* 40 points if it runs properly (expected output for given input, etc., handles all exceptions)  




Please make sure your program at least compiles before you submit it! There will be no partial credit for a program that "almost" compiles.



 



 

*(Thanks to Keith Schwartz and Julie Zelenski for making the dictionary.txt file available)